﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MessengerServer
{
    public class Contact
    {
        public string Name { get; set; }
        public bool Friends { get; set; }
        public int Id { get; set; }
    }
}
